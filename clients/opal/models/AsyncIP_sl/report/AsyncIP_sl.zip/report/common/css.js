function swapClass(obj, cls) {
  obj.className = cls
}
